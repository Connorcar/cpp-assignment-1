a. 2365827
b. ccaruthers@chapman.edu
c. CPSC 298-09
d. Assignment 1: The basics
e. cereal.cpp, firecapacity.cpp, employeepay.cpp
f. N/A
g. N/A